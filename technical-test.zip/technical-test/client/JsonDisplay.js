import React,{Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


class JsonDisplay extends Component{
    constructor(props){
        super(props)

        this.state={Users:[]};
    }
  
    componentDidMount(){
      fetch("http://localhost/personnel")
      .then((res)=>res.json())
      .then(
        result=>{
          this.setState({Users:result});
        }
      
      )
    }

    render(){
        return(<div>
          <h2>Employee Details</h2>
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Reference</th>
                <th>Given Name</th>
                <th>Family NAme</th>
                <th>DOB</th>
                
              </tr>
            </thead>
            <tbody>
                {this.state.Users.map(emp=>(
                    <tr key={emp._id}>
                        <td>{emp._id}</td>
                        <td>{emp.Reference}</td>
                        <td>{emp.GivenName}</td>
                        <td>{emp.FamilyName}</td>
                        <td>{emp.DateOfBirth.substr(0,10)}</td>
                       
                        <td><button className="btn btn-primary">Click</button></td>
                       
                    </tr>
                    

                ))}
            </tbody>
    
            
          </table>
        </div>)
    }




}

export default JsonDisplay;