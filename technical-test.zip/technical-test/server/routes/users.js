import express from 'express';



const router=express.Router();

const users=[
    {
        _id: "571e369aae06d8703c801468",
        Reference: "CS124992",
        GivenName: "Geraldine Mary",
        FamilyName: "Ratcliffe",
        DateOfBirth: "1964-07-28T00:00:00.000+0000"
    },
    {
    _id: "571e369aae06d8703c801469",
    Reference: "CS124993",
    GivenName: "Kate",
    FamilyName: "Wainwright",
    DateOfBirth: "1973-04-22T00:00:00.000+0000"
},
{
    _id: "571e369aae06d8703c80146a",
    Reference: "CS124994",
    GivenName: "Gillian Margaret",
    FamilyName: "Edwards",
    DateOfBirth: "1967-10-09T00:00:00.000+0000"
},
{
    _id: "571e369aae06d8703c80146b",
    Reference: "CS124995",
    GivenName: "Beatrice",
    FamilyName: "Giddins",
    DateOfBirth: "1968-07-30T00:00:00.000+0000"
},
]

router.get('/',(req,res)=>{
    console.log(users);
   res.send(users);


});

export default router; 