import 'regenerator-runtime/runtime'

import React from 'react';
import { render } from 'react-dom';

import App from './client/app.jsx';

render(<App />, document.getElementById('app'));