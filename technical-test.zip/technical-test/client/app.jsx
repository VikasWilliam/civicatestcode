// Implement your react app here

import React,{Component} from 'react';
import Header  from './Header';
import JsonDisplay from './JsonDisplay';

/*export default function App() {
    return <span>{'Hello world'}</span>;
}*/

class App extends Component{
   constructor(){
       super()
   }

    render(){
        return(
        <div>
            <Header/>
            <h2>JSON will be displayed here</h2>
            <JsonDisplay/>
            <hr/>
            <p>&copy; @Technical-test</p>
        </div>
    )
}
}
export default App;
