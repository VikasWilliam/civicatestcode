/*const {readFileSync}= require('fs');
let loadUser=()=> JSON.parse(readFileSync('personnel.json'));

module.exports={loadUser}; */