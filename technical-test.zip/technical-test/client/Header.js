import React from 'react';

const Header=()=>{
    return(
        <div>
            <center>
                <p>Search with Name</p>
                <input type="text"></input>
                <hr/>
            </center>
        </div>
    )
}

export default Header;