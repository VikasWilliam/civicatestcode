// Implement your web server here
import express  from 'express';
import router from './routes/users.js';
import cors from 'cors';


//import bodyParder from 'body-parser';

const PORT = 80;
const app = express();
app.use(
    cors({
        origin:"*",
    })
)

app.use('/personnel', router)

app.get('/',(req,res)=>{
    console.log('[TEST]!');

    res.send('Hello from home');
})

app.listen(PORT, () => console.log(`App running at: http://localhost:${PORT}`));